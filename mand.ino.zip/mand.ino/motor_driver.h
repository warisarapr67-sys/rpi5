#ifndef MOTOR_DRIVER_H
#define MOTOR_DRIVER_H

#include <Arduino.h>
#include "commands.h"

#define LEFT_MOTER_FORWARD  18
#define LEFT_MOTER_BACKWARD  5
#define LEFT_MOTER_ENABLE  25
#define RIGHT_MOTER_FORWARD 4
#define RIGHT_MOTER_BACKWARD 15
#define RIGHT_MOTER_ENABLE 26

void initMotorController();
void setMotorSpeeds(int leftSpeed, int rightSpeed);
void balanceMotors();
#endif
