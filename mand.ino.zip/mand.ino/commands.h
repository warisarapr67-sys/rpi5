#ifndef COMMANDS_H
#define COMMANDS_H

#define GET_BAUDRATE   'b'
#define READ_ENCODERS  'e'
#define MOTOR_RAW_PWM  'o'
#define RESET_ENCODERS 'r'
#define SERVO_MOTOR    's'

#define LEFT  0
#define RIGHT 1

#endif
