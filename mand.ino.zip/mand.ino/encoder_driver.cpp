#include "encoder_driver.h"
#include "commands.h"
#include <ESP32Encoder.h>

ESP32Encoder leftEnc;
ESP32Encoder rightEnc;

void initEncoders() {
  leftEnc.attachHalfQuad(LEFT_ENC_A, LEFT_ENC_B);
  rightEnc.attachHalfQuad(RIGHT_ENC_A, RIGHT_ENC_B);
  resetEncoders();
}

long readEncoder(int i) {
  if (i == LEFT)
    return leftEnc.getCount();
  else
    return rightEnc.getCount();
}

void resetEncoders() {
  leftEnc.clearCount();
  rightEnc.clearCount();
}
