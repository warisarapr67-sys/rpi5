#ifndef SERVOS_H
#define SERVOS_H

#define SERVO_PIN 12

void initServos();
void Servo_do(int degree);

#endif
