#define BAUDRATE 115200

#include <Arduino.h>
#include "commands.h"
#include "motor_driver.h"
#include "encoder_driver.h"
#include "servos.h"

void setup() {
  Serial.begin(BAUDRATE);
  initMotorController();
  initEncoders();
  initServos();
}

void loop() {

  if (Serial.available()) {

    String input = Serial.readStringUntil('\n');
    input.trim();

    if (input.length() > 0) {

      char command = input.charAt(0);

      long value1 = 0;
      long value2 = 0;

      int firstSpace = input.indexOf(' ');
      int secondSpace = input.indexOf(' ', firstSpace + 1);

      if (firstSpace > 0) {
        if (secondSpace > 0) {
          value1 = input.substring(firstSpace + 1, secondSpace).toInt();
          value2 = input.substring(secondSpace + 1).toInt();
        } else {
          value1 = input.substring(firstSpace + 1).toInt();
        }
      }

      switch (command) {

        case 'o':
          setMotorSpeeds(value1, value2);
          Serial.println("OK");
          break;

        case 'e':
          Serial.print(readEncoder(LEFT));
          Serial.print(" ");
          Serial.println(readEncoder(RIGHT));
          break;

        case 'r':
          resetEncoders();
          Serial.println("OK");
          break;

        case 's':
          Servo_do(value1);
          Serial.println("OK");
          break;

        default:
          Serial.println("ERR");
          break;
      }
    }
  }

  // 🔥 ปรับสปีดอัตโนมัติทุกลูป
  balanceMotors();
}
