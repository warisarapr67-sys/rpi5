#ifndef ENCODER_DRIVER_H
#define ENCODER_DRIVER_H

#define LEFT_ENC_A  23
#define LEFT_ENC_B  19
#define RIGHT_ENC_A 16
#define RIGHT_ENC_B 17

void initEncoders();
long readEncoder(int i);
void resetEncoders();

#endif
