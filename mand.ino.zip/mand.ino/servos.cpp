#include "servos.h"
#include <ESP32Servo.h>

Servo myservo;

void initServos() {
  myservo.attach(SERVO_PIN, 1000, 2000);
  myservo.write(90);
}

void Servo_do(int degree) {
  degree = constrain(degree, 0, 180);
  myservo.write(degree);
}
