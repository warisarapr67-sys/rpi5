#include "motor_driver.h"
#include "encoder_driver.h"

#define PWM_FREQ 20000
#define PWM_RES 8
#define MAX_PWM 255

#define CH_L_A 0
#define CH_L_B 1
#define CH_R_A 2
#define CH_R_B 3

int baseLeft = 0;
int baseRight = 0;

long lastLeftEnc = 0;
long lastRightEnc = 0;

void initMotorController() {

  ledcSetup(CH_L_A, PWM_FREQ, PWM_RES);
  ledcSetup(CH_L_B, PWM_FREQ, PWM_RES);
  ledcSetup(CH_R_A, PWM_FREQ, PWM_RES);
  ledcSetup(CH_R_B, PWM_FREQ, PWM_RES);

  ledcAttachPin(LEFT_A, CH_L_A);
  ledcAttachPin(LEFT_B, CH_L_B);
  ledcAttachPin(RIGHT_A, CH_R_A);
  ledcAttachPin(RIGHT_B, CH_R_B);

  ledcWrite(CH_L_A, 0);
  ledcWrite(CH_L_B, 0);
  ledcWrite(CH_R_A, 0);
  ledcWrite(CH_R_B, 0);
}

void applyMotor(int leftSpeed, int rightSpeed) {

  // LEFT
  if (leftSpeed > 0) {
    ledcWrite(CH_L_A, leftSpeed);
    ledcWrite(CH_L_B, 0);
  }
  else if (leftSpeed < 0) {
    ledcWrite(CH_L_A, 0);
    ledcWrite(CH_L_B, -leftSpeed);
  }
  else {
    ledcWrite(CH_L_A, 0);
    ledcWrite(CH_L_B, 0);
  }

  // RIGHT
  if (rightSpeed > 0) {
    ledcWrite(CH_R_A, rightSpeed);
    ledcWrite(CH_R_B, 0);
  }
  else if (rightSpeed < 0) {
    ledcWrite(CH_R_A, 0);
    ledcWrite(CH_R_B, -rightSpeed);
  }
  else {
    ledcWrite(CH_R_A, 0);
    ledcWrite(CH_R_B, 0);
  }
}

void setMotorSpeeds(int leftSpeed, int rightSpeed) {

  leftSpeed  = constrain(leftSpeed,  -MAX_PWM, MAX_PWM);
  rightSpeed = constrain(rightSpeed, -MAX_PWM, MAX_PWM);

  baseLeft = leftSpeed;
  baseRight = rightSpeed;

  lastLeftEnc = readEncoder(LEFT);
  lastRightEnc = readEncoder(RIGHT);

  applyMotor(baseLeft, baseRight);
}

// 🔥 เรียกใน loop เพื่อ balance
void balanceMotors() {

  long newLeft = readEncoder(LEFT);
  long newRight = readEncoder(RIGHT);

  long deltaLeft = newLeft - lastLeftEnc;
  long deltaRight = newRight - lastRightEnc;

  lastLeftEnc = newLeft;
  lastRightEnc = newRight;

  int error = deltaLeft - deltaRight;

  int adjust = error * 2;  // ค่าความแรงการปรับ (ลอง 1-5)

  int correctedRight = baseRight + adjust;

  correctedRight = constrain(correctedRight, -MAX_PWM, MAX_PWM);

  applyMotor(baseLeft, correctedRight);
}
